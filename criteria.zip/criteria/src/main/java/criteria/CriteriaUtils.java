package criteria;

import models.Student;
import utils.HibernateUtils;

import org.hibernate.Session;

import models.Class;
public class CriteriaUtils {

	public static void main(String[] argv) {
		addStudentIncludeClass("Giap Minh Cuong", "Viet Nhat AS K59");
	}
	
	public static void setupData() {
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Student s1 = new Student();
		s1.setStudentName("Giap Minh Cuong");
		
		Student s2 = new Student();
		s2.setStudentName("Thu Uyen");
		
		Class theClass = new Class();
		theClass.setClassName("T1 K28");
		
		theClass.addStudentBidirect(s1);
		theClass.addStudentBidirect(s2);
		
		session.save(theClass);
		
		session.getTransaction().commit();
		session.close();
	}
	public static void deleteStudent(long id) {
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Student s = session.find(Student.class, new Long(id));
		session.remove(s);
		
		session.getTransaction().commit();
		session.close();
	}
	public static void addStudentIncludeClass(String studentName, String className) {
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Student s = new Student();
		s.setStudentName(studentName);

		Class c = new Class();
		c.setClassName(className);

		s.setMyClassBidirect(c);
		
		session.getTransaction().commit();
		session.close();
	}
}
